<?php
//Silent is golden