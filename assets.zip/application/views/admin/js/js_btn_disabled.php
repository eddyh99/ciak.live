<script>
function validate() {
    $("#btnconfirm").attr("disabled", true);
    $("#form_submit").submit();
}
</script>