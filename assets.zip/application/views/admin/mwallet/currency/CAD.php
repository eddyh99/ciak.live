<div class="d-flex flex-row align-items-center my-3">
    <input class="form-control me-2" type="text" name="accountNumber" placeholder="Account Number">
</div>
<div class="d-flex flex-row align-items-center my-3">
    <select name="accountType" class="form-control me-2" id="accountType">
        <option value="">--Account Type--</option>
        <option value="saving">Saving</option>
        <option value="checking">Checking</option>
    </select>
</div>

<?php if ($type == 'local') { ?>
    <div class="d-flex flex-row align-items-center my-3">
        <input class="form-control me-2" type="text" name="interacAccount" placeholder="Interac registered email">
    </div>
<?php } ?>

<div class="d-flex flex-row align-items-center my-3">
    <input class="form-control me-2" type="text" name="institutionNumber" placeholder="Institution Number">
</div>
<div class="d-flex flex-row align-items-center my-3">
    <input class="form-control me-2" type="text" name="transitNumber" placeholder="Transit Number">
</div>