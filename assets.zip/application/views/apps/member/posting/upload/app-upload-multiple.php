
<div class="h-100 col-12 col-xl-8 mx-auto">
    <div id="tui-image-editor-container"></div>
</div>
            