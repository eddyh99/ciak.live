
<div class="withdraw-national-field mb-4">
    <label for="accountNumber">Account Number</label><br>
    <input type="text" name="accountNumber" id="accountNumber" autocomplete="off" maxlength="22">
</div>

<div class="withdraw-national-field mb-4">
    <label for="taxId">TAX ID</label><br>
    <input type="text" name="taxId" id="taxId" autocomplete="off" maxlength="11">
</div>