<div class="withdraw-national-field mb-4">
    <label for="accountNumber">Alipay ID (mobile number or email)</label><br>
    <input class="form-control me-2" type="text" name="accountNumber"  id="accountNumber" autocomplete="off">
</div>