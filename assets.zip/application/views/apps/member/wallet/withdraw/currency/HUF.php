<div class="withdraw-national-field mb-4">
    <label for="accountNumber">Account Number</label><br>
    <input type="text" name="accountNumber" id="accountNumber" autocomplete="off">
</div>

<div class="withdraw-national-field mb-4">
    <label for="iban">IBAN</label><br>
    <input type="text" name="iban" id="iban" autocomplete="off">
</div>