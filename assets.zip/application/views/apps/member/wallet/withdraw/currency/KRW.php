<div class="withdraw-national-field mb-4">
    <label for="accountNumber">Account Number</label><br>
    <input class="form-control me-2" type="text" name="accountNumber" id="accountNumber">
</div>

<div class="withdraw-national-field mb-4">
    <label for="bankCode">Bank Code</label><br>
    <input class="form-control me-2" type="text" name="bankCode" id="bankCode">
</div>

<div class="withdraw-national-field mb-4">
    <label for="dateOfBirth">Date of Birth</label><br>
    <input class="form-control me-2" type="date" name="dateOfBirth" id="dateOfBirth">
</div>

