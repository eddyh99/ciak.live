<div class="withdraw-national-field mb-4">
    <label for="clabe">Clabe</label><br>
    <input class="form-control me-2" type="text" name="clabe">
</div>