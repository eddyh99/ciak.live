<div class="withdraw-national-field mb-4">
    <label for="accountNumber">Account Number</label><br>
    <input class="form-control me-2" type="text" name="accountNumber" id="accountNumber">
</div>

<div class="withdraw-national-field mb-4">
    <label for="BIC">BIC</label><br>
    <input class="form-control me-2" type="text" name="BIC" id="BIC">
</div>