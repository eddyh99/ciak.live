<div class="withdraw-national-field mb-4">
    <label for="accountNumber">Account Number</label><br>
    <input type="text" name="accountNumber" id="accountNumber" autocomplete="off">
</div>

<div class="withdraw-national-field mb-4">
<label for="accountType">Account Type</label><br>
    <select name="accountType" class="form-select select-currency-withdraw me-2" id="accountType">
        <option value="saving">Saving</option>
        <option value="checking">Checking</option>
    </select>
</div>

<div class="withdraw-national-field mb-4">
    <label for="interacAccount">Interac registered email</label><br>
    <input type="text" name="interacAccount" id="interacAccount" autocomplete="off">
</div>

<div class="withdraw-national-field mb-4">
    <label for="institutionNumber">Institution Number</label><br>
    <input type="text" name="institutionNumber" id="institutionNumber" autocomplete="off">
</div>

<div class="withdraw-national-field mb-4">
    <label for="transitNumber">Transit Number</label><br>
    <input type="text" name="transitNumber" id="transitNumber" autocomplete="off">
</div>
