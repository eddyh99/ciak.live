<script>

    $("#btndepo1").click(function () {
        var copyText = document.getElementById("depo1");
        copyText.select();
        copyText.setSelectionRange(0, 99999);
        navigator.clipboard.writeText(copyText.value);
    });

    $("#btndepo2").click(function () {
        var copyText = document.getElementById("depo2");
        copyText.select();
        copyText.setSelectionRange(0, 99999);
        navigator.clipboard.writeText(copyText.value);
    });

    $("#btndepo3").click(function () {
        var copyText = document.getElementById("depo3");
        copyText.select();
        copyText.setSelectionRange(0, 99999);
        navigator.clipboard.writeText(copyText.value);
    });

    $("#btndepo4").click(function () {
        var copyText = document.getElementById("depo4");
        copyText.select();
        copyText.setSelectionRange(0, 99999);
        navigator.clipboard.writeText(copyText.value);
    });

    $("#btndepo5").click(function () {
        var copyText = document.getElementById("depo5");
        copyText.select();
        copyText.setSelectionRange(0, 99999);
        navigator.clipboard.writeText(copyText.value);
    });

    $("#btndepo6").click(function () {
        var copyText = document.getElementById("depo6");
        copyText.select();
        copyText.setSelectionRange(0, 99999);
        navigator.clipboard.writeText(copyText.value);
    });

</script>